package model;

public interface Bookable {
    void book();
}
