package model;

public class Doctor extends Person {
    private int doctorID;
    private String specialization;
    private String email;

    public Doctor() {}

    public Doctor(int doctorID, String name, String gender, String specialization, String email) {
        super(name, gender);
        this.doctorID = doctorID;
        this.specialization = specialization;
        this.email = email;
    }

    public int getDoctorID() { return doctorID; }
    public void setDoctorID(int doctorID) { this.doctorID = doctorID; }

    public String getSpecialization() { return specialization; }
    public void setSpecialization(String specialization) { this.specialization = specialization; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    @Override
    public String toString() {
        return "Doctor{" +
                "doctorID=" + doctorID +
                ", name='" + getName() + '\'' +
                ", gender='" + getGender() + '\'' +
                ", specialization='" + specialization + '\'' +
                ", email='" + email + '\'' +
                '}';
    }
}
