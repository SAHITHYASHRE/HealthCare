import db.DBConnectivity;
import model.Patient;
import model.Doctor;
import model.Appointment;
import model.Feedback;

import java.sql.*;
import java.time.LocalDate;
import java.util.Scanner;

public class Main {
    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        Connection conn = DBConnectivity.getConnection();
        if (conn == null) {
            System.out.println("Exiting: DB connection failed.");
            return;
        }

        while (true) {
            System.out.println("\n===== HEALTHCARE MENU =====");
            System.out.println("1. Add Patient");
            System.out.println("2. View Patients");
            System.out.println("3. Add Doctor");
            System.out.println("4. View Doctors");
            System.out.println("5. Add Appointment");
            System.out.println("6. View Appointments");
            System.out.println("7. Add Feedback");
            System.out.println("8. View Feedback");
            System.out.println("9. Exit");
            System.out.print("Enter your choice: ");

            int choice;
            try {
                choice = Integer.parseInt(sc.nextLine());
            } catch (Exception e) {
                System.out.println("Invalid input. Try again.");
                continue;
            }

            switch (choice) {
                case 1 -> addPatient(conn);
                case 2 -> viewPatients(conn);
                case 3 -> addDoctor(conn);
                case 4 -> viewDoctors(conn);
                case 5 -> addAppointment(conn);
                case 6 -> viewAppointments(conn);
                case 7 -> addFeedback(conn);
                case 8 -> viewFeedback(conn);
                case 9 -> {
                    System.out.println("Exiting system...");
                    try { conn.close(); } catch (SQLException ignored) {}
                    return;
                }
                default -> System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private static void addPatient(Connection conn) {
        try {
            System.out.print("Enter name: ");
            String name = sc.nextLine();

            System.out.print("Enter age: ");
            int age = Integer.parseInt(sc.nextLine());

            System.out.print("Enter gender (Male/Female/Other): ");
            String gender = sc.nextLine();

            System.out.print("Enter contact number: ");
            String contact = sc.nextLine();

            System.out.print("Enter address: ");
            String address = sc.nextLine();

            String sql = "INSERT INTO Patient(name, age, gender, contact_number, address) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, name);
            ps.setInt(2, age);
            ps.setString(3, gender);
            ps.setString(4, contact);
            ps.setString(5, address);
            ps.executeUpdate();
            System.out.println("Patient added successfully.");
            ps.close();
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void viewPatients(Connection conn) {
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery("SELECT * FROM Patient")) {
            System.out.println("\n--- Patients ---");
            while (rs.next()) {
                System.out.printf("ID: %d | Name: %s | Age: %d | Gender: %s | Contact: %s | Address: %s%n",
                        rs.getInt("patient_id"), rs.getString("name"), rs.getInt("age"),
                        rs.getString("gender"), rs.getString("contact_number"), rs.getString("address"));
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void addDoctor(Connection conn) {
        try {
            System.out.print("Enter name: ");
            String name = sc.nextLine();

            System.out.print("Enter specialization: ");
            String specialization = sc.nextLine();

            System.out.print("Enter email: ");
            String email = sc.nextLine();

            String sql = "INSERT INTO Doctor(name, specialization, email) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, specialization);
            ps.setString(3, email);
            ps.executeUpdate();
            System.out.println("Doctor added successfully.");
            ps.close();
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void viewDoctors(Connection conn) {
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery("SELECT * FROM Doctor")) {
            System.out.println("\n--- Doctors ---");
            while (rs.next()) {
                System.out.printf("ID: %d | Name: %s | Specialization: %s | Email: %s%n",
                        rs.getInt("doctor_id"), rs.getString("name"),
                        rs.getString("specialization"), rs.getString("email"));
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void addAppointment(Connection conn) {
        try {
            System.out.print("Enter patient ID: ");
            int patientId = Integer.parseInt(sc.nextLine());

            System.out.print("Enter doctor ID: ");
            int doctorId = Integer.parseInt(sc.nextLine());

            System.out.print("Enter appointment date (YYYY-MM-DD): ");
            LocalDate date = LocalDate.parse(sc.nextLine());

            System.out.print("Enter time slot: ");
            String timeSlot = sc.nextLine();

            System.out.print("Enter status: ");
            String status = sc.nextLine();

            String sql = "INSERT INTO Appointment(patient_id, doctor_id, appointment_date, time_slot, status) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, patientId);
            ps.setInt(2, doctorId);
            ps.setDate(3, Date.valueOf(date));
            ps.setString(4, timeSlot);
            ps.setString(5, status);
            ps.executeUpdate();
            System.out.println("Appointment added successfully.");
            ps.close();
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void viewAppointments(Connection conn) {
        String sql = "SELECT a.appointment_id, p.name AS patient, d.name AS doctor, a.appointment_date, a.time_slot, a.status FROM Appointment a JOIN Patient p ON a.patient_id = p.patient_id JOIN Doctor d ON a.doctor_id = d.doctor_id";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            System.out.println("\n--- Appointments ---");
            while (rs.next()) {
                System.out.printf("ID: %d | Patient: %s | Doctor: %s | Date: %s | Time: %s | Status: %s%n",
                        rs.getInt("appointment_id"), rs.getString("patient"), rs.getString("doctor"),
                        rs.getDate("appointment_date"), rs.getString("time_slot"), rs.getString("status"));
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void addFeedback(Connection conn) {
        try {
            System.out.print("Enter appointment ID: ");
            int appointmentId = Integer.parseInt(sc.nextLine());

            System.out.print("Enter rating (1-5): ");
            int rating = Integer.parseInt(sc.nextLine());

            System.out.print("Enter comments: ");
            String comments = sc.nextLine();

            String sql = "INSERT INTO Feedback(appointment_id, rating, comments) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, appointmentId);
            ps.setInt(2, rating);
            ps.setString(3, comments);
            ps.executeUpdate();
            System.out.println("Feedback submitted.");
            ps.close();
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void viewFeedback(Connection conn) {
        String sql = "SELECT f.feedback_id, p.name AS patient, d.name AS doctor, f.rating, f.comments FROM Feedback f JOIN Appointment a ON f.appointment_id = a.appointment_id JOIN Patient p ON a.patient_id = p.patient_id JOIN Doctor d ON a.doctor_id = d.doctor_id";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            System.out.println("\n--- Feedback ---");
            while (rs.next()) {
                System.out.printf("ID: %d | Patient: %s | Doctor: %s | Rating: %d | Comments: %s%n",
                        rs.getInt("feedback_id"), rs.getString("patient"), rs.getString("doctor"),
                        rs.getInt("rating"), rs.getString("comments"));
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
