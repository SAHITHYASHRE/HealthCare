import db.DBConnectivity;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;
import java.util.Scanner;

public class Main {
    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        try (Connection conn = DBConnectivity.getConnection()) {
            if (conn == null) {
                System.out.println("Exiting: DB connection failed.");
                return;
            }

            while (true) {
                System.out.println("\n===== HEALTHCARE MANAGEMENT SYSTEM =====");
                System.out.println("1. Add Patient");
                System.out.println("2. View Patients");
                System.out.println("3. Add Doctor");
                System.out.println("4. View Doctors");
                System.out.println("5. Add Appointment");
                System.out.println("6. View Appointments");
                System.out.println("7. Add Feedback");
                System.out.println("8. View Feedback");
                System.out.println("9. View Average Rating");
                System.out.println("10. Reschedule Appointment");
                System.out.println("11. Export Appointments");
                System.out.println("12. Export Feedback");
                System.out.println("13. Exit");
                System.out.print("Enter your choice: ");

                try {
                    int choice = Integer.parseInt(sc.nextLine());

                    switch (choice) {
                        case 1 -> addPatient(conn);
                        case 2 -> viewPatients(conn);
                        case 3 -> addDoctor(conn);
                        case 4 -> viewDoctors(conn);
                        case 5 -> addAppointment(conn);
                        case 6 -> viewAppointments(conn);
                        case 7 -> addFeedback(conn);
                        case 8 -> viewFeedback(conn);
                        case 9 -> viewDoctorAverageRating(conn);
                        case 10 -> rescheduleAppointment(conn);
                        case 11 -> exportDoctorAppointments(conn);
                        case 12 -> exportDoctorFeedback(conn);
                        case 13 -> {
                            System.out.println("Exiting system...");
                            return;
                        }
                        default -> System.out.println("Invalid choice. Please enter 1-13.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a number.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Database connection error: " + e.getMessage());
        }
    }

    private static void addPatient(Connection conn) {
        try {
            System.out.print("Enter patient name: ");
            String name = sc.nextLine().trim();
            if (name.isEmpty()) {
                System.out.println("Name cannot be empty.");
                return;
            }

            System.out.print("Enter age: ");
            int age;
            try {
                age = Integer.parseInt(sc.nextLine());
                if (age <= 0 || age > 120) {
                    System.out.println("Age must be between 1 and 120.");
                    return;
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid age. Please enter a number.");
                return;
            }

            System.out.print("Enter gender (Male/Female/Other): ");
            String gender = sc.nextLine().trim();
            if (!gender.equalsIgnoreCase("Male") && !gender.equalsIgnoreCase("Female") && !gender.equalsIgnoreCase("Other")) {
                System.out.println("Gender must be Male, Female, or Other.");
                return;
            }

            System.out.print("Enter contact number: ");
            String contact = sc.nextLine().trim();
            if (contact.length() < 10) {
                System.out.println("Contact number must be at least 10 digits.");
                return;
            }

            System.out.print("Enter address: ");
            String address = sc.nextLine().trim();
            if (address.isEmpty()) {
                System.out.println("Address cannot be empty.");
                return;
            }

            String sql = "INSERT INTO Patient(name, age, gender, contact_number, address) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, name);
                ps.setInt(2, age);
                ps.setString(3, gender);
                ps.setString(4, contact);
                ps.setString(5, address);
                ps.executeUpdate();
                System.out.println("Patient added successfully.");
            }
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }
    }

    private static void viewPatients(Connection conn) {
        String sql = "SELECT * FROM Patient ORDER BY patient_id";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            System.out.println("\n--- PATIENT LIST ---");
            System.out.printf("%-10s %-20s %-5s %-10s %-15s %-30s%n",
                    "ID", "Name", "Age", "Gender", "Contact", "Address");
            System.out.println("----------------------------------------------------------------------");

            while (rs.next()) {
                System.out.printf("%-10d %-20s %-5d %-10s %-15s %-30s%n",
                        rs.getInt("patient_id"),
                        rs.getString("name"),
                        rs.getInt("age"),
                        rs.getString("gender"),
                        rs.getString("contact_number"),
                        rs.getString("address"));
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving patients: " + e.getMessage());
        }
    }

    private static void addDoctor(Connection conn) {
        try {
            System.out.print("Enter doctor name: ");
            String name = sc.nextLine().trim();

            System.out.print("Enter specialization: ");
            String specialization = sc.nextLine().trim();

            System.out.print("Enter email: ");
            String email = sc.nextLine().trim();

            System.out.println("⏳ Processing your request..."); // Debug log

            // Input validation
            if (name.isEmpty() || specialization.isEmpty() || email.isEmpty()) {
                System.out.println("❌ Error: No fields can be empty");
                return;
            }

            String sql = "INSERT INTO Doctor(name, specialization, email) VALUES (?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, name);
                ps.setString(2, specialization);
                ps.setString(3, email);

                int rowsAffected = ps.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("✅ Doctor added successfully!");
                } else {
                    System.out.println("❌ Failed to add doctor");
                }
            }
        } catch (SQLIntegrityConstraintViolationException e) {
            System.out.println("❌ Error: Email already exists or violates a constraint.");
        } catch (SQLException e) {
            System.out.println("❌ Database error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("❌ Unexpected error: " + e.getMessage());
        }
    }

    private static void viewDoctors(Connection conn) {
        String sql = "SELECT * FROM Doctor ORDER BY doctor_id";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            System.out.println("\n--- DOCTOR LIST ---");
            System.out.printf("%-10s %-20s %-25s %-30s%n",
                    "ID", "Name", "Specialization", "Email");
            System.out.println("----------------------------------------------------------------------");

            while (rs.next()) {
                System.out.printf("%-10d %-20s %-25s %-30s%n",
                        rs.getInt("doctor_id"),
                        rs.getString("name"),
                        rs.getString("specialization"),
                        rs.getString("email"));
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving doctors: " + e.getMessage());
        }
    }

    private static void addAppointment(Connection conn) {
        try {
            conn.setAutoCommit(false);

            System.out.print("Enter patient ID: ");
            int patientId = Integer.parseInt(sc.nextLine());

            System.out.print("Enter doctor ID: ");
            int doctorId = Integer.parseInt(sc.nextLine());

            System.out.print("Enter appointment date (YYYY-MM-DD): ");
            LocalDate date = LocalDate.parse(sc.nextLine());
            if (date.isBefore(LocalDate.now())) {
                System.out.println("Appointment date cannot be in the past.");
                conn.rollback();
                return;
            }

            System.out.print("Enter time slot (e.g., 10:00 AM - 11:00 AM): ");
            String timeSlot = sc.nextLine().trim();
            if (timeSlot.isEmpty()) {
                System.out.println("Time slot cannot be empty.");
                conn.rollback();
                return;
            }

            System.out.print("Enter status (Pending/Confirmed/Cancelled): ");
            String status = sc.nextLine().trim();
            if (!status.equalsIgnoreCase("Pending") &&
                    !status.equalsIgnoreCase("Confirmed") &&
                    !status.equalsIgnoreCase("Cancelled")) {
                System.out.println("Invalid status. Must be Pending, Confirmed, or Cancelled.");
                conn.rollback();
                return;
            }

            // Check if doctor is available
            String checkSql = "SELECT COUNT(*) FROM Appointment WHERE doctor_id = ? AND appointment_date = ? AND time_slot = ?";
            try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                checkStmt.setInt(1, doctorId);
                checkStmt.setDate(2, Date.valueOf(date));
                checkStmt.setString(3, timeSlot);

                try (ResultSet rs = checkStmt.executeQuery()) {
                    rs.next();
                    if (rs.getInt(1) > 0) {
                        System.out.println("Doctor is already booked at that time slot.");
                        conn.rollback();
                        return;
                    }
                }
            }

            // Insert new appointment
            String insertSql = "INSERT INTO Appointment(patient_id, doctor_id, appointment_date, time_slot, status) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                insertStmt.setInt(1, patientId);
                insertStmt.setInt(2, doctorId);
                insertStmt.setDate(3, Date.valueOf(date));
                insertStmt.setString(4, timeSlot);
                insertStmt.setString(5, status);
                insertStmt.executeUpdate();
            }

            conn.commit();
            System.out.println("Appointment added successfully.");
        } catch (Exception e) {
            try {
                conn.rollback();
                System.out.println("Transaction rolled back due to error.");
            } catch (SQLException ex) {
                System.out.println("Rollback failed: " + ex.getMessage());
            }
            System.out.println("Error: " + e.getMessage());
        } finally {
            try {
                conn.setAutoCommit(true);
            } catch (SQLException e) {
                System.out.println("Failed to reset auto-commit: " + e.getMessage());
            }
        }
    }

    private static void viewAppointments(Connection conn) {
        String sql = """
            SELECT a.appointment_id, p.name AS patient, d.name AS doctor, 
                   a.appointment_date, a.time_slot, a.status 
            FROM Appointment a 
            JOIN Patient p ON a.patient_id = p.patient_id 
            JOIN Doctor d ON a.doctor_id = d.doctor_id
            ORDER BY a.appointment_date, a.time_slot
            """;

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            System.out.println("\n--- APPOINTMENT SCHEDULE ---");
            System.out.printf("%-10s %-20s %-20s %-15s %-25s %-15s%n",
                    "ID", "Patient", "Doctor", "Date", "Time Slot", "Status");
            System.out.println("--------------------------------------------------------------------------------------------");

            while (rs.next()) {
                System.out.printf("%-10d %-20s %-20s %-15s %-25s %-15s%n",
                        rs.getInt("appointment_id"),
                        rs.getString("patient"),
                        rs.getString("doctor"),
                        rs.getDate("appointment_date"),
                        rs.getString("time_slot"),
                        rs.getString("status"));
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving appointments: " + e.getMessage());
        }
    }

    private static void addFeedback(Connection conn) {
        try {
            System.out.print("Enter appointment ID: ");
            int appointmentId = Integer.parseInt(sc.nextLine());

            System.out.print("Enter rating (1-5): ");
            int rating = Integer.parseInt(sc.nextLine());
            if (rating < 1 || rating > 5) {
                System.out.println("Rating must be between 1 and 5.");
                return;
            }

            System.out.print("Enter comments: ");
            String comments = sc.nextLine().trim();
            if (comments.isEmpty()) {
                System.out.println("Comments cannot be empty.");
                return;
            }

            String sql = "INSERT INTO Feedback(appointment_id, rating, comments) VALUES (?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, appointmentId);
                ps.setInt(2, rating);
                ps.setString(3, comments);
                ps.executeUpdate();
                System.out.println("Feedback submitted successfully.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a number.");
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }
    }

    private static void viewFeedback(Connection conn) {
        String sql = """
            SELECT f.feedback_id, p.name AS patient, d.name AS doctor, 
                   f.rating, f.comments, a.appointment_date
            FROM Feedback f 
            JOIN Appointment a ON f.appointment_id = a.appointment_id 
            JOIN Patient p ON a.patient_id = p.patient_id 
            JOIN Doctor d ON a.doctor_id = d.doctor_id
            ORDER BY f.feedback_id
            """;

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            System.out.println("\n--- PATIENT FEEDBACK ---");
            System.out.printf("%-10s %-20s %-20s %-10s %-50s %-15s%n",
                    "ID", "Patient", "Doctor", "Rating", "Comments", "Appt Date");
            System.out.println("--------------------------------------------------------------------------------------------------------");

            while (rs.next()) {
                System.out.printf("%-10d %-20s %-20s %-10d %-50s %-15s%n",
                        rs.getInt("feedback_id"),
                        rs.getString("patient"),
                        rs.getString("doctor"),
                        rs.getInt("rating"),
                        rs.getString("comments"),
                        rs.getDate("appointment_date"));
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving feedback: " + e.getMessage());
        }
    }

    private static void viewDoctorAverageRating(Connection conn) {
        viewDoctors(conn);

        try {
            System.out.print("Enter doctor ID to view average rating: ");
            int doctorId = Integer.parseInt(sc.nextLine());

            String sql = """
                SELECT d.name AS doctor_name, 
                       AVG(f.rating) AS avg_rating,
                       COUNT(f.feedback_id) AS feedback_count
                FROM Feedback f
                JOIN Appointment a ON f.appointment_id = a.appointment_id
                JOIN Doctor d ON a.doctor_id = d.doctor_id
                WHERE d.doctor_id = ?
                GROUP BY d.name
                """;

            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, doctorId);

                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        System.out.printf("\nDoctor: %s%n", rs.getString("doctor_name"));
                        System.out.printf("Average Rating: %.1f/5 (based on %d feedbacks)%n",
                                rs.getDouble("avg_rating"), rs.getInt("feedback_count"));
                    } else {
                        System.out.println("No feedback found for this doctor.");
                    }
                }
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a number.");
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }
    }

    private static void rescheduleAppointment(Connection conn) {
        viewAppointments(conn);

        try {
            System.out.print("Enter Appointment ID to reschedule: ");
            int id = Integer.parseInt(sc.nextLine());

            System.out.print("Enter new appointment date (YYYY-MM-DD): ");
            LocalDate date = LocalDate.parse(sc.nextLine());
            if (date.isBefore(LocalDate.now())) {
                System.out.println("Cannot reschedule to a past date.");
                return;
            }

            System.out.print("Enter new time slot: ");
            String timeSlot = sc.nextLine().trim();
            if (timeSlot.isEmpty()) {
                System.out.println("Time slot cannot be empty.");
                return;
            }

            System.out.print("Enter new status (Pending/Confirmed/Cancelled): ");
            String status = sc.nextLine().trim();
            if (!status.equalsIgnoreCase("Pending") &&
                    !status.equalsIgnoreCase("Confirmed") &&
                    !status.equalsIgnoreCase("Cancelled")) {
                System.out.println("Invalid status. Must be Pending, Confirmed, or Cancelled.");
                return;
            }

            String sql = "UPDATE Appointment SET appointment_date = ?, time_slot = ?, status = ? WHERE appointment_id = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setDate(1, Date.valueOf(date));
                ps.setString(2, timeSlot);
                ps.setString(3, status);
                ps.setInt(4, id);

                int updated = ps.executeUpdate();
                if (updated > 0) {
                    System.out.println("Appointment rescheduled successfully.");
                } else {
                    System.out.println("No appointment found with ID: " + id);
                }
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a number.");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void exportDoctorAppointments(Connection conn) {
        viewDoctors(conn);

        try {
            System.out.print("Enter Doctor ID to export appointments: ");
            int doctorId = Integer.parseInt(sc.nextLine());

            String sql = """
            SELECT a.appointment_id, a.appointment_date, a.time_slot, a.status,
                   p.name AS patient_name, p.age, p.gender, p.contact_number, p.address,
                   d.name AS doctor_name, d.specialization
            FROM Appointment a
            JOIN Patient p ON a.patient_id = p.patient_id
            JOIN Doctor d ON a.doctor_id = d.doctor_id
            WHERE a.doctor_id = ?
            ORDER BY a.appointment_date, a.time_slot
            """;

            String fileName = "Doctor_" + doctorId + "_Appointments_" + LocalDate.now() + ".txt";

            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, doctorId); // ✅ Set this before executing the query

                try (ResultSet rs = ps.executeQuery();
                     BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {

                    writer.write("=== APPOINTMENTS FOR DOCTOR ID: " + doctorId + " ===\n");
                    writer.write("Export Date: " + LocalDate.now() + "\n\n");

                    int count = 0;
                    while (rs.next()) {
                        count++;
                        writer.write(String.format("""
                            Appointment #%d
                            ID: %d | Date: %s | Time: %s | Status: %s
                            Patient: %s (Age: %d, Gender: %s)
                            Contact: %s | Address: %s
                            Doctor: %s (%s)
                            --------------------------------------
                            """,
                                count,
                                rs.getInt("appointment_id"),
                                rs.getDate("appointment_date"),
                                rs.getString("time_slot"),
                                rs.getString("status"),
                                rs.getString("patient_name"),
                                rs.getInt("age"),
                                rs.getString("gender"),
                                rs.getString("contact_number"),
                                rs.getString("address"),
                                rs.getString("doctor_name"),
                                rs.getString("specialization")));
                    }

                    System.out.println("✅ Successfully exported " + count + " appointments to " + fileName);
                }
            }
        } catch (NumberFormatException e) {
            System.out.println("❌ Invalid input. Please enter a number.");
        } catch (Exception e) {
            System.out.println("❌ Error exporting appointments: " + e.getMessage());
        }
    }

    private static void exportDoctorFeedback(Connection conn) {
        viewDoctors(conn);  // Show available doctors first

        try {
            System.out.print("Enter Doctor ID to export feedback: ");
            int doctorId = Integer.parseInt(sc.nextLine());

            String sql = """
            SELECT f.feedback_id, f.rating, f.comments,
                   p.name AS patient_name, a.appointment_date,
                   d.name AS doctor_name
            FROM Feedback f
            JOIN Appointment a ON f.appointment_id = a.appointment_id
            JOIN Patient p ON a.patient_id = p.patient_id
            JOIN Doctor d ON a.doctor_id = d.doctor_id
            WHERE a.doctor_id = ?
            ORDER BY a.appointment_date DESC
            """;

            String fileName = "Doctor_" + doctorId + "_Feedback_" + LocalDate.now() + ".txt";

            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, doctorId);

                try (ResultSet rs = ps.executeQuery();
                     BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {

                    writer.write("=== FEEDBACK FOR DOCTOR ID: " + doctorId + " ===\n");
                    writer.write("Export Date: " + LocalDate.now() + "\n\n");

                    int count = 0;
                    while (rs.next()) {
                        count++;
                        writer.write(String.format("""
                            Feedback #%d
                            ID: %d | Rating: %d/5 | Date: %s
                            Patient: %s
                            Doctor: %s
                            Comments: %s
                            --------------------------------------
                            """,
                                count,
                                rs.getInt("feedback_id"),
                                rs.getInt("rating"),
                                rs.getDate("appointment_date"),
                                rs.getString("patient_name"),
                                rs.getString("doctor_name"),
                                rs.getString("comments")));
                    }

                    if (count > 0) {
                        System.out.println("✅ Successfully exported " + count + " feedback entries to " + fileName);
                    } else {
                        System.out.println("⚠️ No feedback found for doctor ID: " + doctorId);
                    }
                }
            }
        } catch (NumberFormatException e) {
            System.out.println("❌ Invalid input. Please enter a valid doctor ID number.");
        } catch (SQLException | IOException e) {
            System.out.println("❌ Database error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}